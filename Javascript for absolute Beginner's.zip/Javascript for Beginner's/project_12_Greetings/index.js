friendsNames = ['Amma', "Anum"];
message = "Hello, ";
console.log(message + friendsNames[0]);
console.log(message + friendsNames[1]);
