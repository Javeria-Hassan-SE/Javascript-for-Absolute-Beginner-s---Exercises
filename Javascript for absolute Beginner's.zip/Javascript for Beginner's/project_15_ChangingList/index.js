guestList = ["Alisha", 'Areeba', 'Samreen', 'Anum'];
console.log("Hi "+guestList[0]+". I'm arranging dinner part at my home on Saturday night. You're invited by heart.");
console.log("Hi "+guestList[1]+". I'm arranging dinner part at my home on Saturday night, in treat of your semester ends. Must reach early dear");
console.log("Hi "+guestList[2]+". I'm arranging dinner part at my home on Saturday night. Sweety, You're awaited.");
console.log("Hi "+guestList[3]+". I'm arranging dinner part at my home on Saturday night. Your presence is most important");


console.log("Unfortunately,  "+guestList[2]+" can't join us at dinner due to having work commitment.");
newGuest = "Anabiya";
guestList[2] = newGuest;

console.log("Hi "+guestList[0]+". I'm arranging dinner part at my home on Saturday night. You're invited by heart.");
console.log("Hi "+guestList[1]+". I'm arranging dinner part at my home on Saturday night, in treat of your semester ends. Must reach early dear");
console.log("Hi "+guestList[2]+". I'm arranging dinner part at my home on Saturday night. Sweety, You're awaited.");
console.log("Hi "+guestList[3]+". I'm arranging dinner part at my home on Saturday night. Your presence is most important");

