guestList = ["Alisha", 'Areeba', 'Samreen', 'Anum'];
console.log("I'm inviting "+ guestList.length+ " guests at dinner");
