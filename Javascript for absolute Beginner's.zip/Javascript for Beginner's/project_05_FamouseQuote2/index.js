var famous_quote = "الله کی محبّت کے سوا ہر محبّت کو زوال ہے";
var famous_person = "Umera Ahmed"
var printMessage = famous_person+ " once said:  "+ "\" "+ famous_quote +"\"";

console.log(printMessage);
document.write(printMessage);


