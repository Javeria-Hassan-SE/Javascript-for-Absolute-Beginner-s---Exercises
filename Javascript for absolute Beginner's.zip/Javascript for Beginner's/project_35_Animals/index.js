var animals = ['Persian Cats', 'Pigeons', 'Parrots'];
for (i =0; i<animals.length; i++){
  console.log(animals[i]);
}
for (i =0; i<animals.length; i++){
  console.log(animals[i] + " would be a great pet");
}
console.log("These all are pet animals which I wish to keep");

