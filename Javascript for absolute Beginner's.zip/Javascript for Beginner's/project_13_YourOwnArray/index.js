var modeOfTransportation = ["BMW Car", "Honda Civic"];
console.log("I want to buy "+modeOfTransportation[0]+" at my own for my parents. In sha Allah....");
console.log(modeOfTransportation[1]+" is from one of my favourite car.");