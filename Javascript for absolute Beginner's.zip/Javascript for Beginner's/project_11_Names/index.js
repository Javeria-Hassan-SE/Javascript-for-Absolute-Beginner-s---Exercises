friendsNames = ['Amma', "Anum"];
console.log(friendsNames[0]);
console.log(friendsNames[1]);