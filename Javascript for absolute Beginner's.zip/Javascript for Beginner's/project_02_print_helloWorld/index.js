var personName = "Javeria";
var printMessage = "Hello "+personName +"!. Would you like to learn Javascript today?";
console.log(printMessage);
document.write(printMessage);