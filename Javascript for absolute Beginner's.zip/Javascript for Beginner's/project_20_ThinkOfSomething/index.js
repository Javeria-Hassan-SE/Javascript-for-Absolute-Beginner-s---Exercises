favouriteBooks = ["Jannat Kay Pattay", "Mushaf", "Maala", "Haalim"];
console.log(favouriteBooks);