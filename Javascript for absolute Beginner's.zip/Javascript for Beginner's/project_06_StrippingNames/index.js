var personName = "\t Javeria hassan\n";


var printMessage = personName;
console.log(printMessage);
console.log(printMessage.trim());
document.write(printMessage);


