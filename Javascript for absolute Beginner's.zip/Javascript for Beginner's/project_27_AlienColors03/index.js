var alien_color  = 'green';
if (alien_color ==  'green'){
  console.log("Player Earn 5 Points");
}
else if(alien_color ==  'yellow'){
  console.log("Player Earn 10 Points");
}
else if(alien_color ==  'red'){
  console.log("Player Earn 15 Points");
}
else{
  console.log("No points");
}
