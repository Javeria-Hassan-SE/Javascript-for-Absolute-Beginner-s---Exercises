var favouriteNumber = 2 ;
var message = "My Favourite Number : " +favouriteNumber;
console.log(message);
document.write(message);


