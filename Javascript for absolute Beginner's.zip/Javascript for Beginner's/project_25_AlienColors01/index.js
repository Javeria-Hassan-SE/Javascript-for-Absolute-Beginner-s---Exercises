var alien_color  = 'green';
if (alien_color ==  'green'){
  console.log("Player Earn 5 Points");
}
else{
  
}
