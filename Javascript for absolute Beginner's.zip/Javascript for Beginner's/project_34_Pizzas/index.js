var pizzas = ['Pepperoni Pizza', 'Meat Pizza', 'Cheese Pizza'];
for(i=0; i<pizzas.length; i++){
  if(pizzas[i]=='Pepperoni Pizza'){
    console.log("I Love ", pizzas[i]);
  }
  else if(pizzas[i]=='Meat Pizza'){
    console.log("I like ", pizzas[i]);
  }
  else if(pizzas[i]=='Cheese Pizza'){
    console.log("I like ", pizzas[i]);
  }
}
console.log("I usaually dont eat pizza, but sometimes eating pizza is like having a great pleasure.");