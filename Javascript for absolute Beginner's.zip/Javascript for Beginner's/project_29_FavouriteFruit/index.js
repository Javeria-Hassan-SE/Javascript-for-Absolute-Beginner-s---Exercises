favorite_fruits = ['Mangos', 'Grapes', 'Pomegranates', 'Bananas'];

for (i=0; i<favorite_fruits.length; i++){
  if(favorite_fruits[i]=='Grapes'){
    console.log("You really like ",favorite_fruits[i]);
  }
  else if(favorite_fruits[i]=='Apple'){
    console.log("You really like ",favorite_fruits[i]);
  }
  else if(favorite_fruits[i]=='Banana'){
    console.log("You really like ",favorite_fruits[i]);
  }
  else if(favorite_fruits[i]=='Kiwi'){
    console.log("You really like ",favorite_fruits[i]);
  }
  else if(favorite_fruits[i]=='Berries'){
    console.log("You really like ",favorite_fruits[i]);
  }
}