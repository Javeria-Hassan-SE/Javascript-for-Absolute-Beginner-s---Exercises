guestList = ["Alisha", 'Areeba', 'Samreen', 'Anum'];
for (i=0;i<guestList.length;i++){
  console.log(guestList[i]);
}