describe_city("Karachi","Pakistan");
describe_city("Islamabad","Pakistan");
describe_city("Istanbul","Turkey");
function describe_city(city, country){
  console.log(city+" , "+country);
}
