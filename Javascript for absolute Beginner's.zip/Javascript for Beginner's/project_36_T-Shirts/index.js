var text = "You Beautiful";
var size = 24;

make_shirt(text,size);

function make_shirt(text, size){
  console.log(text,size);
}
