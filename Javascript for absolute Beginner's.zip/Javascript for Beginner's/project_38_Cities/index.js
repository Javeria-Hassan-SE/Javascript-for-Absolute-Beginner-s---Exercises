country = "Pakistan"

describe_city("Karachi",country);
describe_city("Islamabad",country);
describe_city("Istanbul","Turkey");
function describe_city(city, country){
  console.log(city+" is in "+country);
}
