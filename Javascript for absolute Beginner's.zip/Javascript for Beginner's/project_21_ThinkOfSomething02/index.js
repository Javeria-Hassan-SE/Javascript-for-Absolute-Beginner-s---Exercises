const person = {firstName:"Javeria", lastName:"Hassan", age:21, education:"BSCS"};
console.log(person);