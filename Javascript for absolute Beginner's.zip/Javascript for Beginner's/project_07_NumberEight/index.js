
var add = 6+2;
var sub = 10-2;
var mul = 2* 4;
var div = 16/2;
console.log(add);
console.log(sub);
console.log(mul);
console.log(div);

