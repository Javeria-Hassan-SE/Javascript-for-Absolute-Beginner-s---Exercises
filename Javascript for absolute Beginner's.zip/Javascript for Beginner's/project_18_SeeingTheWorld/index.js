placesToVisit = ["Saudia Arabia", "Turkey","Greenland","DisneyLand", "Los Angles", "Islamabad"];
console.log("Original Order List: ");
console.log(placesToVisit);
console.log("Aplhabetical Order List: ");
console.log((placesToVisit.slice()).sort());//Sort() function will sort the list, slice function will make a copy of original list
console.log("Original Order List: ");
console.log(placesToVisit);
console.log("Reverse Alphabetical Order List: ");
console.log(((placesToVisit.slice()).sort()).reverse());//Sort() function will sort the list, slice() function will make a copy of original list
console.log("Original Order List: ");
console.log(placesToVisit);
console.log("Reverse Order List: ");
console.log(placesToVisit.reverse());//reverse() function will reverse the list
console.log("Re-Reverse Order List: ");
console.log(placesToVisit.reverse());//reverse() function will reverse the list
console.log("Aplhabetical Order List: ");
console.log(placesToVisit.sort());//Sort() function will sort the list
console.log("Reverse Aplhabetical Order List: ");
console.log(placesToVisit.reverse());//reverse() function will reverse the list
