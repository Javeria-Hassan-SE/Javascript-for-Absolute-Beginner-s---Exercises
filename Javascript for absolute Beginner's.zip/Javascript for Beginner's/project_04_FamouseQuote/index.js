var printMessage ="Umera Ahmed once said:  "+ "\" "+ "الله کی محبّت کے سوا ہر محبّت کو زوال ہے" +"\"";

console.log(printMessage);
document.write(printMessage);


