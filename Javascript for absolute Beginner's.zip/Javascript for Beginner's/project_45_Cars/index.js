console.log(carInfo("HONDA", "CIVIC","Grey"));

function carInfo(manufacturer, modelName,color){
 car ={
  manufacturer:manufacturer,
  modelName: modelName,
  color: color
 }
 return car;
}


