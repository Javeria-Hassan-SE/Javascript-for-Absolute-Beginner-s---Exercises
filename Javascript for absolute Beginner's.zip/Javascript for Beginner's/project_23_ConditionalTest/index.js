let car = 'BMW';
let color = 'blue';
let myName = 'Javeria';
let uni = 'PAF-KIET';
let city = 'Karachi';
let country = 'Pakistan';
let language = "Javascript";
let profession = "Full Stack Web and Application Developer";
let life = "easy";
let programmer = 'no life';

console.log("Test 1");
console.log("Is car == 'BMW'? I predict True.");
console.log(car == 'BMW');

console.log("Test 2");
console.log("Is color == 'blue'? I predict False.");
console.log(color == 'blue');

console.log("Test 3");
console.log("Is myName == 'Javeria'? I predict True.");
console.log(myName == 'Javeria');

console.log("Test 4");
console.log("Is uni == 'PAF-KIET'? I predict True.");
console.log(uni == 'PAF-KIET');

console.log("Test 5");
console.log("Is city == 'Karachi'? I predict True.");
console.log(city == 'Karachi');

console.log("Test 6");
console.log("Is country == 'Pakistan'? I predict True.");
console.log(country == 'Pakistan');

console.log("Test 7");
console.log("Is language == 'Javascript'? I predict False.");
console.log(language == 'Javascript');

console.log("Test 8");
console.log("Is profession == 'Full Stack Web and Application Developer'? I predict False.");
console.log(profession == 'Full Stack Web and Application Developer');

console.log("Test 9");
console.log("Is life == 'easy'? I predict False.");
console.log(life == 'easy');

console.log("Test 10");
console.log("Is programmer == 'no life'? I predict False.");
console.log(programmer == 'no life');