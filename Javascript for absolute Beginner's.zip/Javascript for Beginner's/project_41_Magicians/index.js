var magicians = ['Magician 1', 'Magician 2', 'Magician 3'];
show_magicians(magicians);

function show_magicians(magicians){
  for (i=0; i<magicians.length; i++){
    console.log(magicians[i]);
  }
}